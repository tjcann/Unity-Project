using UnityEngine;

public class Credits : MonoBehaviour
{
    public void Quit()
    {
        Application.Quit();
        Debug.Log("quit");
    }
}
